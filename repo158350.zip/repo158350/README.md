# repo158350
Dokonuje zmiany Jan Wołoszyn